# VA Lab Logo

There are both .SVG and .PNG formats for all versions of the logo.

In the root of this folder there is a Figma design file (.FIG) which was used to create the logo.

If you want to edit the logo, please load the .FIG file into Figma.

Instructions can be found here: <https://help.figma.com/hc/en-us/articles/360041003114-Import-files-into-Figma>
